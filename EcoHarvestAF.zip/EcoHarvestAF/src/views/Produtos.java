/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package views;

import BD.MySQL;
import com.mysql.cj.xdevapi.Statement;
import com.sun.jdi.connect.spi.Connection;
import javax.swing.JOptionPane;
import objetos.Funcionario;
import objetos.Produto;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JTable;
import objetos.Fornecedor;

/**
 *
 * @author Leandro
 */
public class Produtos extends javax.swing.JFrame {
    
    MySQL conectar = new MySQL();
    Produto novoProduto = new Produto();
    private java.sql.Connection conn = null;
    /**
     * Creates new form Produtos
     */
    public Produtos() {
        initComponents();
        ComboBoxFornecedor();
        setLocationRelativeTo(null);
        setTitle("EcoHarvest - Produtos");
    }
    
    private void cadastrarProduto(Produto novoProduto){
        this.conectar.conectaBanco();
        
            //Vinculando os textos das caixas de texto ao objeto novoProduto
        novoProduto.setNome(txtNomeProduto.getText());
        novoProduto.setPeso(Float.parseFloat(txtPeso.getText()));
        novoProduto.setDisponibilidade(txtDisponibilidade.getSelectedItem().toString());
        novoProduto.setQntdEstoque(Integer.parseInt(txtQntdEstoque.getText()));
        novoProduto.setValorCompra(Double.parseDouble(txtCompra.getText()));
        novoProduto.setValorVenda(Double.parseDouble(txtVenda.getText()));
        novoProduto.setIdFornecedor(id_fornecedor.get(txtFornecedor.getSelectedIndex()-1).toString());

        try{
            this.conectar.insertSQL("INSERT INTO produto (nome, peso, disponibilidade, qntd_estoque, valor_compra, valor_venda, id_fornecedor) VALUES ('"
                    + novoProduto.getNome() + "', " 
                    + novoProduto.getPeso() + ", '"
                    + novoProduto.getDisponibilidade() + "', "
                    + novoProduto.getQntdEstoque() + ", "
                    + novoProduto.getValorCompra() + ", "
                    + novoProduto.getValorVenda() + ", "
                    + novoProduto.getIdFornecedor() +             
                    ")"
            );       
        } catch(Exception e){
            System.out.println("Erro ao cadastrar Produto" + e.getMessage());
        } finally{
            this.conectar.fechaBanco();
            limparCamposCadastro();
            JOptionPane.showMessageDialog(rootPane, "Produto Cadastrado com sucesso!");
        }                           
    }
    
    private void buscarProduto(Produto novoProduto){
        this.conectar.conectaBanco();
        
        String txtIdProduto = this.txtIdProduto.getText();
            
        try {
            this.conectar.viewSQL(
                "SELECT "
                    + "P.nome, "                    
                    + "P.peso, "
                    + "P.disponibilidade, "	
                    + "P.qntd_estoque, "
                    + "P.valor_compra, "
                    + "P.valor_venda, "
                    + "P.id_fornecedor, "
                    + "F.nome "       
                + " FROM"
                    + " produto P"
                + " JOIN" 
                    + " fornecedor F" 
                + " ON" 
                    + " P.id_fornecedor = F.id "
                + " WHERE"
                    + " P.id = '" + txtIdProduto + "'"
                + ";"
            );

            while(this.conectar.getResultSet().next()){
                novoProduto.setNome(this.conectar.getResultSet().getString(1));
                novoProduto.setPeso(this.conectar.getResultSet().getFloat(2));
                novoProduto.setDisponibilidade(this.conectar.getResultSet().getString(3));
                novoProduto.setQntdEstoque(this.conectar.getResultSet().getInt(4));
                novoProduto.setValorCompra(this.conectar.getResultSet().getDouble(5));
                novoProduto.setValorVenda(this.conectar.getResultSet().getDouble(6));
                novoProduto.setIdFornecedor(this.conectar.getResultSet().getString(8));
            }
            
            if("".equals(novoProduto.getNome())){
                JOptionPane.showMessageDialog(null, "Funcionário não encontrado!");
            }  
                
        }catch (Exception e) {            
            System.out.println("Erro ao consultar funcionário " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar funcionário");      
        }finally {
            fieldNomeProduto1.setText(novoProduto.getNome());
            fieldPeso1.setText (String.valueOf(novoProduto.getPeso()));
            txtDisponibilidade1.setSelectedItem(novoProduto.getDisponibilidade());
            fieldQntdEstoque1.setText(String.valueOf(novoProduto.getQntdEstoque()));
            fieldCompra1.setText(String.valueOf(novoProduto.getValorCompra()));
            fieldVenda1.setText(String.valueOf(novoProduto.getValorVenda()));
            fieldFornecedor1.setSelectedItem(novoProduto.getIdFornecedor());
            this.conectar.fechaBanco();   
        }               
    }
    
    public void atualizarProduto(Produto novoProduto){
        this.conectar.conectaBanco();
        
        String txtIdProduto = this.txtIdProduto.getText();
        
        try {
            this.conectar.updateSQL(
                "UPDATE produto SET "                    
                    + "nome = '" + fieldNomeProduto1.getText() + "',"                  
                    + "peso = '" + fieldPeso1.getText() + "',"
                    + "disponibilidade = '" + txtDisponibilidade1.getSelectedItem() + "',"
                    + "qntd_estoque = '" + fieldQntdEstoque1.getText() + "',"
                    + "valor_compra = '" + fieldCompra1.getText() + "',"
                    + "valor_venda = '" + fieldVenda1.getText() + "'"
                    //+ "id_fornecedor = '" + fieldFornecedor1.getSelectedItem() + "' "
                    + " WHERE id = '" + txtIdProduto + "'"
                    + ";"
            );         
        }catch(Exception e){
            System.out.println("Erro ao atualizar Produto " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar Produto");
        }finally{
            this.conectar.fechaBanco();
            JOptionPane.showMessageDialog(null, "Produto atualizado com sucesso");
        }
    }
    
    private void deletarProduto(Produto novoProduto){
        this.conectar.conectaBanco();
        
        String txtIdProduto = this.txtIdProduto.getText(); 
        
        try {            
            this.conectar.updateSQL(
                "DELETE FROM produto "
                + " WHERE "
                    + "id = '" + txtIdProduto + "'"
                + ";"            
            );          
        }catch (Exception e) {           
            System.out.println("Erro ao deletar produto " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar produto");
        }finally{
            this.conectar.fechaBanco();
            limparCamposBusca();
            JOptionPane.showMessageDialog(null, "Produto deletado com sucesso");            
        }            
    }
    
    
    Vector<Integer> id_fornecedor = new Vector<Integer>();

    public void ComboBoxFornecedor(){
        
        this.conectar.conectaBanco();
              
        try {
            this.conectar.viewSQL( "SELECT id, nome FROM fornecedor;"); 
            
           while (this.conectar.getResultSet().next()){ 
            id_fornecedor.addElement(this.conectar.getResultSet().getInt(1));
            txtFornecedor.addItem(this.conectar.getResultSet().getString(2));
            fieldFornecedor1.addItem(this.conectar.getResultSet().getString(2));
           }
            
        }catch (Exception e) {           
            JOptionPane.showMessageDialog(null, "Erro ao selecionar Fornecedor" +  e.getMessage());
        }
    }    
    
    
    public void limparCamposCadastro() {
        txtNomeProduto.setText("");
        txtPeso.setText("");
        txtDisponibilidade.setSelectedItem("");
        txtQntdEstoque.setText("");
        txtCompra.setText("");
        txtVenda.setText("");
        fieldFornecedor1.setSelectedItem("");
    }  
    
    public void limparCamposBusca() {
        fieldNomeProduto1.setText("");
        fieldPeso1.setText("");
        txtDisponibilidade1.setSelectedItem("");
        fieldQntdEstoque1.setText("");
        fieldCompra1.setText("");
        fieldVenda1.setText("");
        fieldFornecedor1.setSelectedItem("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtNomeProduto = new javax.swing.JTextField();
        txtPeso = new javax.swing.JTextField();
        txtQntdEstoque = new javax.swing.JTextField();
        txtVenda = new javax.swing.JTextField();
        txtCompra = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        btnRegister = new javax.swing.JButton();
        txtDisponibilidade = new javax.swing.JComboBox<>();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel17 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jButton2 = new javax.swing.JButton();
        txtIdProduto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        btnView = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        fieldNomeProduto1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        fieldCompra1 = new javax.swing.JTextField();
        fieldPeso1 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        fieldVenda1 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        fieldQntdEstoque1 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        fieldFornecedor1 = new javax.swing.JComboBox<>();
        txtFornecedor = new javax.swing.JComboBox<>();
        txtDisponibilidade1 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(460, 315));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 0));
        jLabel1.setText("Cadastrar Produto");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, -1, 40));

        jLabel2.setText("Nome do produto:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 100, 20));

        jLabel3.setText("Peso do Produto:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 100, 20));

        jLabel4.setText("Disponibilidade:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 130, -1, 20));

        jLabel5.setText("Quantidade em Estoque:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, -1, 20));

        jLabel6.setText("Valor de Compra:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, -1, 20));

        jLabel7.setText("Valor de Venda:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 90, -1, 20));

        jLabel8.setText("Fornecedor:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 70, 20));
        jPanel1.add(txtNomeProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 110, -1));
        jPanel1.add(txtPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 110, -1));
        jPanel1.add(txtQntdEstoque, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, 70, -1));
        jPanel1.add(txtVenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, 70, -1));
        jPanel1.add(txtCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 50, 70, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, 150, 20));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 160, 20));

        btnRegister.setBackground(new java.awt.Color(0, 102, 0));
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("Cadastrar Produto");
        btnRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 130, 30));

        txtDisponibilidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Disponivel", "Indisponivel" }));
        jPanel1.add(txtDisponibilidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 110, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 160, 20));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 102, 0));
        jLabel17.setText("Gerenciar Produto");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 0, -1, 40));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 20, 150, 20));

        jButton2.setText("Limpar Campos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 280, 130, 30));

        txtIdProduto.setText("0");
        txtIdProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdProdutoActionPerformed(evt);
            }
        });
        jPanel1.add(txtIdProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, 50, -1));

        jLabel9.setText("ID do Produto:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, -1, 20));

        btnView.setForeground(new java.awt.Color(0, 102, 0));
        btnView.setText("Visualizar");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        jPanel1.add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, -1, -1));

        btnUpdate.setBackground(new java.awt.Color(203, 229, 255));
        btnUpdate.setForeground(new java.awt.Color(0, 0, 102));
        btnUpdate.setText("Atualizar");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 50, 80, -1));

        btnDelete.setBackground(new java.awt.Color(255, 153, 153));
        btnDelete.setForeground(new java.awt.Color(51, 0, 0));
        btnDelete.setText("Deletar");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 50, 80, -1));

        jButton1.setText("Limpar Campos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, 130, 30));

        jLabel13.setText("Nome do produto:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, 100, 20));
        jPanel1.add(fieldNomeProduto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 110, 110, -1));

        jLabel12.setText("Valor de Compra:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, -1, 20));
        jPanel1.add(fieldCompra1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 110, 70, -1));
        jPanel1.add(fieldPeso1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 150, 110, -1));

        jLabel11.setText("Valor de Venda:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 150, -1, 20));
        jPanel1.add(fieldVenda1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 150, 70, -1));

        jLabel14.setText("Peso do Produto:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 100, 20));

        jLabel15.setText("Disponibilidade:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 190, -1, 20));

        jLabel10.setText("Quantidade em Estoque:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 190, -1, 20));
        jPanel1.add(fieldQntdEstoque1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 190, 70, -1));

        jLabel16.setText("Fornecedor:");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, 70, 20));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, new java.awt.Color(206, 206, 206)));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 10, 490));

        btnBack.setText("Voltar");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 280, -1, 30));

        fieldFornecedor1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        jPanel1.add(fieldFornecedor1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 230, 110, -1));

        txtFornecedor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        txtFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFornecedorActionPerformed(evt);
            }
        });
        jPanel1.add(txtFornecedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 110, -1));

        txtDisponibilidade1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Disponivel", "Indisponivel" }));
        jPanel1.add(txtDisponibilidade1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, 110, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 920, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        cadastrarProduto(novoProduto);
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        limparCamposBusca();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        limparCamposCadastro();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        deletarProduto(novoProduto);
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        atualizarProduto(novoProduto);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        int produtoID = Integer.parseInt(txtIdProduto.getText());

        Produto produto = new Produto();

        buscarProduto(produto);

        // Preenche os campos com os dados do produto
        txtNomeProduto.setText(novoProduto.getNome());
        txtPeso.setText (String.valueOf(novoProduto.getPeso()));
        txtDisponibilidade.setSelectedItem(novoProduto.getDisponibilidade());
        txtQntdEstoque.setText(String.valueOf(novoProduto.getQntdEstoque()));
        txtCompra.setText(String.valueOf(novoProduto.getValorCompra()));
        txtVenda.setText(String.valueOf(novoProduto.getValorVenda()));
        fieldFornecedor1.setSelectedItem(String.valueOf(novoProduto.getIdFornecedor()));
    }//GEN-LAST:event_btnViewActionPerformed

    private void txtIdProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdProdutoActionPerformed

    }//GEN-LAST:event_txtIdProdutoActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        Funcionalidades funcionalidades = new Funcionalidades();
        funcionalidades.setVisible(true);
        dispose();

    }//GEN-LAST:event_btnBackActionPerformed

    private void txtFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFornecedorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Produtos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Produtos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Produtos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Produtos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Produtos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnView;
    private javax.swing.JTextField fieldCompra1;
    private javax.swing.JComboBox<String> fieldFornecedor1;
    private javax.swing.JTextField fieldNomeProduto1;
    private javax.swing.JTextField fieldPeso1;
    private javax.swing.JTextField fieldQntdEstoque1;
    private javax.swing.JTextField fieldVenda1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTextField txtCompra;
    private javax.swing.JComboBox<String> txtDisponibilidade;
    private javax.swing.JComboBox<String> txtDisponibilidade1;
    private javax.swing.JComboBox<String> txtFornecedor;
    private javax.swing.JTextField txtIdProduto;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtQntdEstoque;
    private javax.swing.JTextField txtVenda;
    // End of variables declaration//GEN-END:variables
}
