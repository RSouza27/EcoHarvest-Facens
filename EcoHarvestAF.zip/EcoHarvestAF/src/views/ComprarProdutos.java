/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package views;

import BD.MySQL;
import java.util.Vector;
import javax.swing.JOptionPane;
import objetos.Compra;
import objetos.Fornecedor;
import objetos.Produto;
import objetos.Funcionario;


/**
 *
 * @author Leandro
 */
public class ComprarProdutos extends javax.swing.JFrame {
       
     MySQL conectar = new MySQL();
     Produto novoProduto = new Produto();
     Funcionario novoFuncionario = new Funcionario();
     Compra comprarProduto  = new Compra();
     
    /**
     * Creates new form TelaComprarProdutos
     */
    public ComprarProdutos() {
        initComponents();
        
        /*cbxProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            cbxProdutoActionPerformed(evt);
            }
        }); */

        ComboBoxProduto();
        ComboBoxFuncionario();
        setLocationRelativeTo(null);
        setTitle("EcoHarvest - Comprar Produtos");
    }
    
    Vector<Integer> produto = new Vector<Integer>();
    
    public void ComboBoxProduto(){
        
        this.conectar.conectaBanco();
              
        try {
            this.conectar.viewSQL( "SELECT p.id, p.nome, f.id, f.nome  FROM fornecedor f  JOIN produto p ON p.id_fornecedor = f.id"); 
            
            while (this.conectar.getResultSet().next()){ 
            produto.addElement(this.conectar.getResultSet().getInt(1));
            cbxProduto.addItem(this.conectar.getResultSet().getString(2));
            fieldProduto1.addItem(this.conectar.getResultSet().getString(2)); 
           }
            
        }catch (Exception e) {           
            JOptionPane.showMessageDialog(null, "Erro ao selecionar Produto" +  e.getMessage());
        }
    } 
    
    Vector<Integer> id_funcionario = new Vector<Integer>();

    public void ComboBoxFuncionario(){
        
        this.conectar.conectaBanco();
              
        try {
            this.conectar.viewSQL( "SELECT id, nome FROM funcionario;"); 
            
           while (this.conectar.getResultSet().next()){ 
            id_funcionario.addElement(this.conectar.getResultSet().getInt(1));
            cbxFuncionario.addItem(this.conectar.getResultSet().getString(2));
            fieldFuncionario1.addItem(this.conectar.getResultSet().getString(2));
           }
            
        }catch (Exception e) {           
            JOptionPane.showMessageDialog(null, "Erro ao selecionar Funcionário" +  e.getMessage());
        }
    }
    
    private void Compra(Compra comprarProduto ) {
        this.conectar.conectaBanco();
        
        comprarProduto.setId_produto(produto.get(cbxProduto.getSelectedIndex()-1).toString());
        comprarProduto.setFuncionario(id_funcionario.get(cbxFuncionario.getSelectedIndex()-1).toString()); 
        comprarProduto.setQtd_pedido(Integer.parseInt(txtQuantidade.getText()));

        try {
            String sql = "INSERT INTO pedido (id_produto, id_funcionario, qtd_pedido) VALUES ('"
                    + comprarProduto.getId_produto() + "', '"
                    + comprarProduto.getFuncionario() + "', '"
                    + comprarProduto.getQtd_pedido() + "')";

            this.conectar.insertSQL(sql);

            JOptionPane.showMessageDialog(rootPane, "Pedido de  compra cadastrado com sucesso!");
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar Pedido de compra: " + e.getMessage());
        } finally {
            this.conectar.fechaBanco();
        }
    }
    
    private void buscarPedido(Compra comprarProduto){
        this.conectar.conectaBanco();
        
        String txtIdPedido = this.txtIdPedido.getText();
            
        try {
            this.conectar.viewSQL(
                    "SELECT "
                    + "pe.id, "                    
                    + "pr.nome,  "
                    + "f.nome, "	
                    + "pe.qtd_pedido "      
                + " FROM"
                    + " pedido pe"
                + " JOIN" 
                    + " funcionario f" 
                + " JOIN" 
                    + " produto pr"
                + " ON" 
                    + " pe.id_funcionario = f.id AND pe.id_produto = pr.id "
                + " WHERE"
                    + " pe.id = '" + txtIdPedido + "'"
                + ";"
            );

            while(this.conectar.getResultSet().next()){
                comprarProduto.setId_produto(this.conectar.getResultSet().getString(2));
                comprarProduto.setFuncionario(this.conectar.getResultSet().getString(3));
                comprarProduto.setQtd_pedido(this.conectar.getResultSet().getInt(4));
            }

            if("".equals(comprarProduto.getId_pedido())){
                JOptionPane.showMessageDialog(null, "Pedido de compra não encontrado!");
            }      
        }catch (Exception e) {            
            System.out.println("Erro ao consultar pedido " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar pedido");      
        }finally {
            fieldProduto1.setSelectedItem(comprarProduto.getId_produto());
            fieldFuncionario1.setSelectedItem(comprarProduto.getFuncionario());
            fieldQuantidade1.setText(String.valueOf(comprarProduto.getQtd_pedido()));
            this.conectar.fechaBanco();   
        }               
    }

    public void atualizarPedido(Compra comprarProduto){
        this.conectar.conectaBanco();
        
        String txtIdPedido = this.txtIdPedido.getText();
        
        try {
            this.conectar.updateSQL(
                "UPDATE pedido SET "                    
                    + "id_funcionario = '" + fieldFuncionario1.getSelectedIndex() + "',"                  
                    + "id_produto = '" + fieldProduto1.getSelectedIndex() + "',"
                    + "qtd_pedido = '" + fieldQuantidade1.getText()  + "'"
                    //+ "id_fornecedor = '" + fieldFornecedor1.getSelectedItem() + "' "
                    + " WHERE id = '" + txtIdPedido + "'"
                    + ";"
            );         
        }catch(Exception e){
            System.out.println("Erro ao atualizar Pedido de compra " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar Pedido de compra");
        }finally{
            this.conectar.fechaBanco();
            JOptionPane.showMessageDialog(null, "Pedido de compra atualizado com sucesso");
        }
    }

    private void deletarPedido(Compra comprarProduto){
        this.conectar.conectaBanco();
        
        String txtIdPedido = this.txtIdPedido.getText(); 
        
        try {            
            this.conectar.updateSQL(
                "DELETE FROM pedido "
                + " WHERE "
                    + "id = '" + txtIdPedido + "'"
                + ";"            
            );          
        }catch (Exception e) {           
            System.out.println("Erro ao deletar pedido de compra " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar pedido de compra ");
        }finally{
            this.conectar.fechaBanco();
            //limparCamposBusca();
            JOptionPane.showMessageDialog(null, "Pedido de compra deletado com sucesso");            
        }            
    }
    
    public void limparCamposCadastro() {
        cbxProduto.setSelectedItem("");
        cbxFuncionario.setSelectedItem("");
        txtQuantidade.setText("");
    } 
    
    public void limparCamposBusca() {
        fieldProduto1.setSelectedItem("");
        fieldFuncionario1.setSelectedItem("");
        fieldQuantidade1.setText("");
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonBack = new javax.swing.JButton();
        cbxFuncionario = new javax.swing.JComboBox<>();
        labelEmployee = new javax.swing.JLabel();
        cbxProduto = new javax.swing.JComboBox<>();
        labelProducts = new javax.swing.JLabel();
        labelQntd = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        buttonBack1 = new javax.swing.JButton();
        fieldFuncionario1 = new javax.swing.JComboBox<>();
        labelEmployee1 = new javax.swing.JLabel();
        fieldProduto1 = new javax.swing.JComboBox<>();
        labelProducts1 = new javax.swing.JLabel();
        labelQntd1 = new javax.swing.JLabel();
        fieldQuantidade1 = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        tituloProdutos1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtIdPedido = new javax.swing.JTextField();
        btnView = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnLimparBusca = new javax.swing.JButton();
        btnBuy = new javax.swing.JButton();
        btnLimparCad = new javax.swing.JButton();
        tituloProdutos = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttonBack.setText("Voltar");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });
        getContentPane().add(buttonBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 210, 98, -1));

        cbxFuncionario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        getContentPane().add(cbxFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 160, -1));

        labelEmployee.setText("Funcionário:");
        getContentPane().add(labelEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        cbxProduto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        cbxProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxProdutoActionPerformed(evt);
            }
        });
        getContentPane().add(cbxProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 64, 160, -1));

        labelProducts.setText("Produto:");
        getContentPane().add(labelProducts, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 67, -1, -1));

        labelQntd.setText("Quantidade:");
        getContentPane().add(labelQntd, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 67, -1, -1));

        txtQuantidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQuantidadeActionPerformed(evt);
            }
        });
        getContentPane().add(txtQuantidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(356, 64, 75, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(294, 18, 340, 15));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 18, 130, 15));

        buttonBack1.setText("Voltar");
        buttonBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBack1ActionPerformed(evt);
            }
        });
        getContentPane().add(buttonBack1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 220, 98, -1));

        fieldFuncionario1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        getContentPane().add(fieldFuncionario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 160, 160, -1));

        labelEmployee1.setText("Funcionário:");
        getContentPane().add(labelEmployee1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 160, -1, -1));

        fieldProduto1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        fieldProduto1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldProduto1ActionPerformed(evt);
            }
        });
        getContentPane().add(fieldProduto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, 160, -1));

        labelProducts1.setText("Produto:");
        getContentPane().add(labelProducts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 120, -1, -1));

        labelQntd1.setText("Quantidade:");
        getContentPane().add(labelQntd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 120, -1, -1));
        getContentPane().add(fieldQuantidade1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 120, 75, -1));
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 20, 144, 15));

        tituloProdutos1.setBackground(new java.awt.Color(0, 102, 0));
        tituloProdutos1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tituloProdutos1.setText("Gerenciar Pedidos");
        getContentPane().add(tituloProdutos1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 0, -1, 40));

        jLabel1.setText("ID do pedido:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 80, 20));
        getContentPane().add(txtIdPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 70, -1));

        btnView.setForeground(new java.awt.Color(0, 102, 0));
        btnView.setText("Visualizar");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        getContentPane().add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, -1, -1));

        btnUpdate.setBackground(new java.awt.Color(203, 229, 255));
        btnUpdate.setForeground(new java.awt.Color(0, 0, 102));
        btnUpdate.setText("Atualizar");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        getContentPane().add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 70, 80, -1));

        btnDelete.setBackground(new java.awt.Color(255, 153, 153));
        btnDelete.setForeground(new java.awt.Color(51, 0, 0));
        btnDelete.setText("Deletar");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        getContentPane().add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 70, 80, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, new java.awt.Color(206, 206, 206)));
        jPanel3.setPreferredSize(new java.awt.Dimension(10, 269));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 10, 490));

        btnLimparBusca.setText("Limpar Campos");
        btnLimparBusca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparBuscaActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimparBusca, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 220, 160, -1));

        btnBuy.setBackground(new java.awt.Color(0, 102, 0));
        btnBuy.setForeground(new java.awt.Color(255, 255, 255));
        btnBuy.setText("Efetuar Compra");
        btnBuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuyActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuy, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 160, -1));

        btnLimparCad.setText("Limpar Campos");
        btnLimparCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparCadActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimparCad, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 160, -1));

        tituloProdutos.setBackground(new java.awt.Color(0, 102, 0));
        tituloProdutos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tituloProdutos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloProdutos.setText("Gerenciar Pedidos");
        jPanel1.add(tituloProdutos, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 130, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 270));
        getContentPane().add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 18, 190, 15));
        getContentPane().add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 18, 190, 15));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed
        Funcionalidades page = new Funcionalidades();
        page.setVisible (true);
        dispose();
    }//GEN-LAST:event_buttonBackActionPerformed

    private void btnBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuyActionPerformed
        Compra(comprarProduto);
    }//GEN-LAST:event_btnBuyActionPerformed

    private void cbxProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxProdutoActionPerformed
          
    }//GEN-LAST:event_cbxProdutoActionPerformed

    private void buttonBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBack1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonBack1ActionPerformed

    private void fieldProduto1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldProduto1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldProduto1ActionPerformed

    private void txtQuantidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQuantidadeActionPerformed
        
    }//GEN-LAST:event_txtQuantidadeActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        int pedidoID = Integer.parseInt(txtIdPedido.getText());

        Compra comprarProduto = new Compra();

        buscarPedido(comprarProduto);

        // Preenche os campos com os dados do produto
        fieldProduto1.setSelectedItem(comprarProduto.getId_produto());
        fieldFuncionario1.setSelectedItem(comprarProduto.getFuncionario());
        fieldQuantidade1.setText(String.valueOf(comprarProduto.getQtd_pedido()));
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        atualizarPedido(comprarProduto);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        deletarPedido(comprarProduto);
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnLimparBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparBuscaActionPerformed
        limparCamposBusca();
    }//GEN-LAST:event_btnLimparBuscaActionPerformed

    private void btnLimparCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparCadActionPerformed
        limparCamposCadastro();
    }//GEN-LAST:event_btnLimparCadActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ComprarProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ComprarProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ComprarProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ComprarProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ComprarProdutos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuy;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnLimparBusca;
    private javax.swing.JButton btnLimparCad;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnView;
    private javax.swing.JButton buttonBack;
    private javax.swing.JButton buttonBack1;
    private javax.swing.JComboBox<String> cbxFuncionario;
    private javax.swing.JComboBox<String> cbxProduto;
    private javax.swing.JComboBox<String> fieldFuncionario1;
    private javax.swing.JComboBox<String> fieldProduto1;
    private javax.swing.JTextField fieldQuantidade1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JLabel labelEmployee;
    private javax.swing.JLabel labelEmployee1;
    private javax.swing.JLabel labelProducts;
    private javax.swing.JLabel labelProducts1;
    private javax.swing.JLabel labelQntd;
    private javax.swing.JLabel labelQntd1;
    private javax.swing.JLabel tituloProdutos;
    private javax.swing.JLabel tituloProdutos1;
    private javax.swing.JTextField txtIdPedido;
    private javax.swing.JTextField txtQuantidade;
    // End of variables declaration//GEN-END:variables
}
