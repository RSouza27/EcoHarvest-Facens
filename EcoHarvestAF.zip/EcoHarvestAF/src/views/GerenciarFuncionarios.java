/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package views;

import BD.MySQL;
import java.awt.TextField;
import javax.swing.JOptionPane;
import objetos.Funcionario;
import objetos.Usuario;

/**
 *
 * @author Leandro
 */
public class GerenciarFuncionarios extends javax.swing.JFrame {

    MySQL conectar = new MySQL();
    Funcionario novoFuncionario = new Funcionario();
    private int funcionarioID;

    public GerenciarFuncionarios() {
        initComponents();
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        
        setLocationRelativeTo(null);
        setTitle("EcoHarvest - Cadastro de Funcionário");
    }

    private void cadastrarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        //Vinculando os textos das caixas de texto ao objeto novoProduto
        novoFuncionario.setNome(txtNome.getText());
        novoFuncionario.setSobrenome(txtSobrenome.getText());
        novoFuncionario.setEmail(txtEmail.getText());
        novoFuncionario.setCargo(txtCargo.getText());      
        novoFuncionario.setNascimento(txtNascimento.getText());
        novoFuncionario.setCelular(txtCelular.getText());
        novoFuncionario.setGenero(txtGenero.getSelectedItem().toString());
        novoFuncionario.setSalario(Double.parseDouble(txtSalario.getText()));

        try{
            this.conectar.insertSQL("INSERT INTO funcionario (nome, sobrenome, email, cargo, nascimento, celular, genero, salario) VALUES ('"
                    + novoFuncionario.getNome() + "', '" 
                    + novoFuncionario.getSobrenome() + "', '"
                    + novoFuncionario.getEmail() + "', '"
                    + novoFuncionario.getCargo() + "', '"
                    + novoFuncionario.getNascimento() + "', '"
                    + novoFuncionario.getCelular() + "', '"
                    + novoFuncionario.getGenero() + "', '"
                    + novoFuncionario.getSalario() +             
                    "')"
            );       
        } catch(Exception e){
            System.out.println("Erro ao cadastrar funcionario" + e.getMessage());
        } finally{
            this.conectar.fechaBanco();
            limparCamposCadastro();
            JOptionPane.showMessageDialog(rootPane, "Funcionário Cadastrado com sucesso!");
        }                           
    } 
    
    private void buscarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String fieldID = this.fieldID.getText();
            
        try {
            this.conectar.viewSQL(
                   "SELECT "
                    + "nome,"                    
                    + "sobrenome,"
                    + "email,"
                    + "cargo,"
                    + "nascimento,"
                    + "celular,"
                    + "genero,"
                    + "salario"
                 + " FROM"
                     + " funcionario"
                 + " WHERE"
                     + " id = '" + fieldID + "'"
                + ";"
            );

            while(this.conectar.getResultSet().next()){
                novoFuncionario.setNome(this.conectar.getResultSet().getString(1));
                novoFuncionario.setSobrenome(this.conectar.getResultSet().getString(2));
                novoFuncionario.setEmail(this.conectar.getResultSet().getString(3));
                novoFuncionario.setCargo(this.conectar.getResultSet().getString(4));
                novoFuncionario.setNascimento(this.conectar.getResultSet().getString(5));
                novoFuncionario.setCelular(this.conectar.getResultSet().getString(6));
                novoFuncionario.setGenero(this.conectar.getResultSet().getString(7));
                novoFuncionario.setSalario(this.conectar.getResultSet().getDouble(8));
            }

      
        }catch (Exception e) {            
            System.out.println("Erro ao consultar funcionário " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar funcionário");      
        }finally {
            
            if(novoFuncionario.getNome().equals("")){
            JOptionPane.showMessageDialog(null, "Funcionário não encontrado!");
            }
            
            fieldNome1.setText(novoFuncionario.getNome());
            fieldSobrenome1.setText(novoFuncionario.getSobrenome());
            fieldEmail1.setText(novoFuncionario.getEmail());
            fieldCargo1.setText(novoFuncionario.getCargo());
            fieldNascimento1.setText(novoFuncionario.getNascimento());
            fieldCelular1.setText(novoFuncionario.getCelular());
            fieldGenero1.setSelectedItem(novoFuncionario.getGenero());
            fieldSalario1.setText(String.valueOf(novoFuncionario.getSalario()));
            this.conectar.fechaBanco();   
        }               
    }
    
    public void atualizarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String fieldID = this.fieldID.getText();
        
        try {
            this.conectar.updateSQL(
                "UPDATE funcionario SET "                    
                    + "nome = '" + fieldNome1.getText() + "',"                  
                    + "sobrenome = '" + fieldSobrenome1.getText() + "',"
                    + "email = '" + fieldEmail1.getText() + "',"
                    + "cargo = '" + fieldCargo1.getText() + "',"
                    + "nascimento = '" + fieldNascimento1.getText() + "',"
                    + "celular = '" + fieldCelular1.getText() + "',"
                    + "genero = '" + fieldGenero1.getSelectedItem() + "',"
                    + "salario = '" + fieldSalario1.getText() + "' "
                    + " WHERE id = '" + fieldID + "'"
                    + ";"
            );         
        }catch(Exception e){
            System.out.println("Erro ao atualizar funcionário " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar funcionário");
        }finally{
            this.conectar.fechaBanco();
            JOptionPane.showMessageDialog(null, "Funcionário atualizado com sucesso");
        }
    }
    
    private void deletarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String fieldID = this.fieldID.getText(); 
        
        try {            
            this.conectar.updateSQL(
                "DELETE FROM funcionario "
                + " WHERE "
                    + "id = '" + fieldID + "'"
                + ";"            
            );          
        }catch (Exception e) {           
            System.out.println("Erro ao deletar Funcionário " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar funcionário");
        }finally{
            this.conectar.fechaBanco();
            limparCamposBusca();
            JOptionPane.showMessageDialog(null, "Funcionário deletado com sucesso");            
        }            
    }
    
    public void limparCamposCadastro() {
        txtNome.setText("");
        txtSobrenome.setText("");
        txtEmail.setText("");
        txtCargo.setText("");
        txtNascimento.setText("");
        txtCelular.setText("");
        txtGenero.setSelectedItem("");
        txtSalario.setText("");
    }    
    
    public void limparCamposBusca() {
        fieldNome1.setText("");
        fieldSobrenome1.setText("");
        fieldEmail1.setText("");
        fieldCargo1.setText("");
        fieldNascimento1.setText("");
        fieldCelular1.setText("");
        fieldGenero1.setSelectedItem("");
        fieldSalario1.setText("");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCargo = new javax.swing.JTextField();
        txtSalario = new javax.swing.JFormattedTextField();
        txtGenero = new javax.swing.JComboBox<>();
        txtCelular = new javax.swing.JTextField();
        txtNascimento = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnRegister = new javax.swing.JButton();
        txtSobrenome = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        fieldID = new javax.swing.JTextField();
        btnView = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        lblLogin2 = new javax.swing.JLabel();
        fieldSalario1 = new javax.swing.JFormattedTextField();
        jLabel8 = new javax.swing.JLabel();
        fieldEmail1 = new javax.swing.JTextField();
        fieldNome1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        fieldNascimento1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        fieldGenero1 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        fieldSobrenome1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        fieldCelular1 = new javax.swing.JTextField();
        fieldCargo1 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        labelFacaCadastro1 = new javax.swing.JLabel();
        labelFacaCadastro = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        jButton2 = new javax.swing.JButton();
        labelFacaCadastro2 = new javax.swing.JLabel();
        labelFacaCadastro3 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setText("Gênero: ");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 50, -1));

        jLabel1.setText("E-mail:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 150, 40, 20));

        jLabel2.setText("Cargo:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));
        jPanel1.add(txtCargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 125, -1));
        jPanel1.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 180, 89, -1));

        txtGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Feminino", "Masculino", " " }));
        txtGenero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroActionPerformed(evt);
            }
        });
        jPanel1.add(txtGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 150, -1, -1));
        jPanel1.add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 89, -1));

        txtNascimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNascimentoActionPerformed(evt);
            }
        });
        jPanel1.add(txtNascimento, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 90, 89, -1));

        jLabel17.setText("Data de Nascimento:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, -1, 20));

        jLabel4.setText("Salário:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, -1, -1));

        jLabel5.setText("Telefone:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 120, -1, 20));
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 125, -1));

        btnRegister.setBackground(new java.awt.Color(0, 102, 0));
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("Cadastrar");
        btnRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 125, 30));
        jPanel1.add(txtSobrenome, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 125, -1));

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });
        jPanel1.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 125, -1));

        jLabel3.setText("      Nome:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 60, 20));

        jLabel15.setText("Sobrenome:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, 20));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, new java.awt.Color(206, 206, 206)));
        jPanel2.setForeground(new java.awt.Color(206, 206, 206));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fieldID.setText("0");
        fieldID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldIDActionPerformed(evt);
            }
        });
        jPanel2.add(fieldID, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, -1, -1));

        btnView.setForeground(new java.awt.Color(0, 102, 0));
        btnView.setText("Visualizar");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        jPanel2.add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, -1, -1));

        btnDelete.setBackground(new java.awt.Color(255, 153, 153));
        btnDelete.setForeground(new java.awt.Color(51, 0, 0));
        btnDelete.setText("Deletar");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel2.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 100, -1, -1));

        btnUpdate.setBackground(new java.awt.Color(203, 229, 255));
        btnUpdate.setForeground(new java.awt.Color(0, 0, 102));
        btnUpdate.setText("Atualizar");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        jPanel2.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, -1, -1));

        jLabel7.setText("ID funcionário:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 20));

        lblLogin2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblLogin2.setForeground(new java.awt.Color(0, 51, 0));
        lblLogin2.setText("Administrar cadastro");
        jPanel2.add(lblLogin2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));
        jPanel2.add(fieldSalario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 270, 89, -1));

        jLabel8.setText("      Nome:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 20));
        jPanel2.add(fieldEmail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 125, -1));

        fieldNome1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNome1ActionPerformed(evt);
            }
        });
        jPanel2.add(fieldNome1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 125, -1));

        jLabel9.setText("Telefone:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, -1, 20));

        jLabel11.setText("Cargo:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        fieldNascimento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNascimento1ActionPerformed(evt);
            }
        });
        jPanel2.add(fieldNascimento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 180, 89, -1));

        jLabel10.setText("E-mail:");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 40, 20));

        fieldGenero1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Feminino", "Masculino", " " }));
        fieldGenero1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldGenero1ActionPerformed(evt);
            }
        });
        jPanel2.add(fieldGenero1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 240, -1, -1));

        jLabel18.setText("Data de Nascimento:");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 180, -1, 20));
        jPanel2.add(fieldSobrenome1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 125, -1));

        jLabel12.setText("Salário:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, -1, -1));

        jLabel13.setText("Gênero: ");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 240, 50, -1));
        jPanel2.add(fieldCelular1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, 89, -1));
        jPanel2.add(fieldCargo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, 125, -1));

        jLabel16.setText("Sobrenome:");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 20));

        btnBack.setText("Voltar");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel2.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 320, -1, -1));

        labelFacaCadastro1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labelFacaCadastro1.setForeground(new java.awt.Color(0, 51, 0));
        labelFacaCadastro1.setText("Dados Pessoais");
        jPanel2.add(labelFacaCadastro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        labelFacaCadastro.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        labelFacaCadastro.setForeground(new java.awt.Color(0, 51, 0));
        labelFacaCadastro.setText("Administrar funcionario");
        jPanel2.add(labelFacaCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));
        jPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 100, 12));
        jPanel2.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 110, 12));

        jButton2.setText("Limpar Campos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 125, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 0, 440, 360));

        labelFacaCadastro2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labelFacaCadastro2.setForeground(new java.awt.Color(0, 51, 0));
        labelFacaCadastro2.setText("Dados Pessoais");
        jPanel1.add(labelFacaCadastro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        labelFacaCadastro3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        labelFacaCadastro3.setForeground(new java.awt.Color(0, 51, 0));
        labelFacaCadastro3.setText("Cadastrar funcionario");
        jPanel1.add(labelFacaCadastro3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, -1));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 130, 12));
        jPanel1.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, 120, 12));

        jButton1.setText("Limpar Campos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 125, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        cadastrarFuncionario(novoFuncionario);
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        Funcionalidades funcionalidades = new Funcionalidades();
        funcionalidades.setVisible(true);
        dispose();
                
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNascimentoActionPerformed

    private void txtGeneroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGeneroActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        deletarFuncionario(novoFuncionario);
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        atualizarFuncionario(novoFuncionario);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        int funcionarioID = Integer.parseInt(fieldID.getText());

        Funcionario funcionario = new Funcionario();

        buscarFuncionario(funcionario);

        // Preenche os campos com os dados do funcionário
        fieldNome1.setText(funcionario.getNome());
        fieldSobrenome1.setText(funcionario.getSobrenome());
        fieldEmail1.setText(funcionario.getEmail());
        fieldCargo1.setText(funcionario.getCargo());
        fieldNascimento1.setText(funcionario.getNascimento());
        fieldCelular1.setText(funcionario.getCelular());
        fieldGenero1.setSelectedItem(funcionario.getGenero());
        fieldSalario1.setText(String.valueOf(funcionario.getSalario()));
    }//GEN-LAST:event_btnViewActionPerformed

    private void fieldIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldIDActionPerformed

    }//GEN-LAST:event_fieldIDActionPerformed

    private void fieldNome1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNome1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNome1ActionPerformed

    private void fieldNascimento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNascimento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNascimento1ActionPerformed

    private void fieldGenero1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldGenero1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldGenero1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        limparCamposCadastro();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        limparCamposBusca();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GerenciarFuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GerenciarFuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GerenciarFuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GerenciarFuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GerenciarFuncionarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnView;
    private javax.swing.JTextField fieldCargo1;
    private javax.swing.JTextField fieldCelular1;
    private javax.swing.JTextField fieldEmail1;
    private javax.swing.JComboBox<String> fieldGenero1;
    private javax.swing.JTextField fieldID;
    private javax.swing.JTextField fieldNascimento1;
    private javax.swing.JTextField fieldNome1;
    private javax.swing.JFormattedTextField fieldSalario1;
    private javax.swing.JTextField fieldSobrenome1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JLabel labelFacaCadastro;
    private javax.swing.JLabel labelFacaCadastro1;
    private javax.swing.JLabel labelFacaCadastro2;
    private javax.swing.JLabel labelFacaCadastro3;
    private javax.swing.JLabel lblLogin2;
    private javax.swing.JTextField txtCargo;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JComboBox<String> txtGenero;
    private javax.swing.JTextField txtNascimento;
    private javax.swing.JTextField txtNome;
    private javax.swing.JFormattedTextField txtSalario;
    private javax.swing.JTextField txtSobrenome;
    // End of variables declaration//GEN-END:variables
}
