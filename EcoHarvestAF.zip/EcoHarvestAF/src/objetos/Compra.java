/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

/**
 *
 * @author Leandro
 */
public class Compra {
    private int id_pedido;
    private String id_produto;
    private String nome_produto;
    private int qtd_pedido ;
    private String funcionario;
    
    
    
    
        public int getId_pedido() {
        return id_pedido;
    }

    /**
     * @param id_pedido the id_pedido to set
     */
    public void setId_pedido(int id_pedido) {
        this.id_pedido = id_pedido;
    }
    
    /**
     * @return the id_produto
     */
    public String getId_produto() {
        return id_produto;
    }

    /**
     * @param id_produto the id_produto to set
     */
    public void setId_produto(String id_produto) {
        this.id_produto = id_produto;
    }

    /**
     * @return the nome_produto
     */
    public String getNome_produto() {
        return nome_produto;
    }

    /**
     * @param nome_produto the nome_produto to set
     */
    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    /**
     * @return the qtd_pedido
     */
    public int getQtd_pedido() {
        return qtd_pedido;
    }

    /**
     * @param qtd_pedido the qtd_pedido to set
     */
    public void setQtd_pedido(int qtd_pedido) {
        this.qtd_pedido = qtd_pedido;
    }

    /**
     * @return the funcionario
     */
    public String getFuncionario() {
        return funcionario;
    }

    /**
     * @param funcionario the funcionario to set
     */
    public void setFuncionario(String funcionario) {
        this.funcionario = funcionario;
    }

}
