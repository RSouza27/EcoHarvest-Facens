/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import BD.MySQL;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Leandro
 */
public class Produto {
    
    MySQL conectar = new MySQL();
    java.sql.Statement statement;
    Connection conn = null;
    
    private int id;
    private String nome;
    private float peso;
    private String disponibilidade;
    private int qntd_estoque;
    private double valor_compra;
    private double valor_venda;
    private String id_fornecedor;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(String disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public int getQntdEstoque() {
        return qntd_estoque;
    }

    public void setQntdEstoque(int qtnd_estoque) {
        this.qntd_estoque = qtnd_estoque;
    }

    public double getValorCompra() {
        return valor_compra;
    }

    public void setValorCompra(double valor_compra) {
        this.valor_compra = valor_compra;
    }

    public double getValorVenda() {
        return valor_venda;
    }

    public void setValorVenda(double valor_venda) {
        this.valor_venda = valor_venda;
    }

    public String getIdFornecedor() {
        return id_fornecedor;
    }

    public void setIdFornecedor(String id_fornecedor) {
        this.id_fornecedor = id_fornecedor;
    }
    
   
}


