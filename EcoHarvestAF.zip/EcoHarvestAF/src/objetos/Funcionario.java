/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

/**
 *
 * @author Leandro
 */
public class Funcionario {
    private int    id = 0;
    private String nome = "";
    private String sobrenome = "";
    private String email = "";
    private String cargo = "";
    private String nascimento = "";
    private String celular = "";
    private String genero = "";
    private double salario = 0.00;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getSobrenome(){
        return sobrenome;
    }
    
    public void setSobrenome (String sobrenome) {
        this.sobrenome = sobrenome;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail (String email) {
        this.email = email;
    }
    
    public String getCargo(){
        return cargo;
    }
    
    public void setCargo (String cargo) {
        this.cargo = cargo;
    }
    
    public String getNascimento(){
        return nascimento;
    }
    
    public void setNascimento (String nascimento) {
        this.nascimento = nascimento;
    }
    
    public String getCelular(){
        return celular;
    }
    
    public void setCelular (String celular) {
        this.celular = celular;
    }
    
    public String getGenero(){
        return genero;
    }
    
    public void setGenero (String genero) {
        this.genero = genero;
    }
    
    public double getSalario (){
        return salario;
    }
    
    public void setSalario (double salario) {
        this.salario = salario;
    }
    
}
